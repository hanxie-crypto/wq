package com.example.mysurfaceview;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.SurfaceHolder.Callback;

public class MyServiceView extends SurfaceView implements Callback{
	private SurfaceHolder sfh;
	private Paint paint;
	private Bitmap bmp;
	private Bitmap bmp2;
	public MyServiceView(Context context) {
		super(context);
		sfh=this.getHolder();
		sfh.addCallback(this);
		paint=new Paint();
		paint.setColor(Color.WHITE);
		bmp=BitmapFactory.decodeResource(this.getResources(), R.drawable.sea);
		bmp2=BitmapFactory.decodeResource(this.getResources(), R.drawable.cls1_2);
		
	}


	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		myDraw();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}
 public void myDraw(){
	 Canvas canvas=sfh.lockCanvas();
	 canvas.drawColor(Color.BLACK);
	 canvas.drawBitmap(bmp, 0,0, paint);
	 canvas.save();
	 canvas.translate(20, 40);
	 canvas.drawBitmap(bmp2, 0,0, paint);
	 canvas.restore();
	 sfh.unlockCanvasAndPost(canvas);
 }


@Override
public void surfaceChanged(SurfaceHolder holder, int format, int width,
		int height) {
	// TODO Auto-generated method stub
	
}
}
